/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package form;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 2130203
 */
@WebServlet("/form")
public class FormServlet extends HttpServlet {
  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
          
        response.setContentType("text/html");
        PrintWriter writer = response.getWriter();
 
        String name = request.getParameter("username");
        String age = request.getParameter("userage");
        String medicine = request.getParameter("medicine");
        String level = request.getParameter("level");
        String[] comforts = request.getParameterValues("comforts");
         
        try {
            writer.println("<p>Name: " + name + "</p>");
            writer.println("<p>Age: " + age + "</p>");
            writer.println("<p>Medicine: " + medicine + "</p>");
            writer.println("<p>Sick level: " + level + "</p>");
            writer.println("<h4>Comforts</h4>");
            for(String comfort: comforts)
                writer.println("<li>" + comfort + "</li>");
        } finally {
            writer.close();  
        }
    }
}