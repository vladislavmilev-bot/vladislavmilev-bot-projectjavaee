/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation;

import java.io.IOException;
import java.util.Date;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 *
 * @author Ульяна
 */
@WebServlet("/apiExample")
public class ValidationExample extends HttpServlet {
    @Inject
    Medic medic;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().write(medic.name + "");
    }
}

class Medic {
    @NotNull
    @Pattern.List({
            @Pattern(regexp = "[A-Z][a-z]*"), 
            @Pattern(regexp = "")})
    String name;
    @Min(18)
            @Null 
            int age;
    @Size(max = 500, min = 100)
    String skills;
    @Past
    Date bithDate;
    @Future
    Date deathDate;
    String surname;
@NotNull
    public String getSurname() {
        return surname;
    }

    public void setSurname(@NotNull @Pattern(regexp = "[A-Z]") String surname) {
        this.surname = surname;
    }
    
}
