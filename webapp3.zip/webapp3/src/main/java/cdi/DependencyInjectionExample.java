/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;
import javax.inject.Inject;
import javax.inject.Qualifier;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/diExample")
public class DependencyInjectionExample extends HttpServlet {
   @Inject
   @PatientAnotation
Medicine medicine;
   @Inject
   @DoctorAnotation
   Medicine doctor;


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                  System.out.println(medicine.getName());
                  System.out.println(doctor.getName());

    }
}
    @Qualifier
    @Retention(RUNTIME)
    @Target({METHOD, FIELD, PARAMETER, TYPE})
    @interface PatientAnotation {}

    interface Medicine  {
        String getName();
    }
 @PatientAnotation
class Patient implements Medicine {
    private String name;

    public String getName() {
        name = "Patient";
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
        
}
@Qualifier
    @Retention(RUNTIME)
    @Target({FIELD, METHOD, PARAMETER, TYPE})
    @interface DoctorAnotation {}

@DoctorAnotation
class Doctor implements Medicine {

    @Override
    public String getName() {
        return "doctor";
    }
    
}
