/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import javax.decorator.Decorator;
import javax.decorator.Delegate;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/decorExample")
public class DecoratorExample extends HttpServlet{
    @Inject
    Transplantation transplantation;
   @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                transplantation.print();
    }
}
interface Transplantation {
    void print();
}
class Heart implements Transplantation {
    @Override
    public void print() {
        System.out.println("print");
    }
}
@Decorator
class MyDecorator implements Transplantation { 
    @Inject
    @Delegate
    Transplantation transplantation;
    @Override
    public void print() {
        System.out.println("before print");
        transplantation.print();
        System.out.println("after print");
    }
}