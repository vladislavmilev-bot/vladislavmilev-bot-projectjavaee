/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;
import javax.inject.Inject;
import javax.inject.Qualifier;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/alterExample")
public class Alternative extends HttpServlet {
   @Inject
Hospital hospital;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                  System.out.println(hospital.getName());
    }
}
    interface Hospital  {
        String getName();
    }
 @javax.enterprise.inject.Alternative
class Worker implements Hospital {
    public String getName() {
        return "worker";
    }
        
}


class Nurse implements Hospital {

    @Override
    public String getName() {
        return "nurse";
    }
    
}
