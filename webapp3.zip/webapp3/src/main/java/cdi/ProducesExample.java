/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/prodExample")
public class ProducesExample extends HttpServlet{
    @Inject
    String s;
    @Inject
    int i;
    @Inject
    double d;
    @Inject
    Tool tool;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().write(s + "" + 1 + "" + d + "" + tool.name);
}
}
   
class Pills {
    @Produces
    String s = "hello hospital";
    @Produces
    int i = 5;
    @Produces
    double getDouble() {
        return 1 + 3.3 + 5.8;
    }
    @Produces
    Tool getTool() {
        return new Tool("Scalp");
    }
}
class Tool {
    String name;

    public Tool(String name) {
        this.name = name;
    }
    
}