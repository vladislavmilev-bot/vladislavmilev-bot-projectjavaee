/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/dispExample")
public class DisposerExample extends HttpServlet{
    
    @Inject
    Therapy therapy;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().write(therapy.name);
    }
}
   
class Cure {
    @Produces
    Therapy getTherapy() {
        return new Therapy("4weeks");
    }
    
    public void clean(@Disposes Therapy therapy) {
        therapy.clean();
    }
}
class Therapy {
    String name;

    public Therapy(String name) {
        this.name = name;
    }
    public void clean() {
        System.out.println("therapy 4weeks");
    }
}