/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdi;

import java.io.IOException;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.interceptor.AroundConstruct;
import javax.interceptor.AroundInvoke;
import javax.interceptor.ExcludeClassInterceptors;
import javax.interceptor.Interceptor;
import javax.interceptor.Interceptors;
import javax.interceptor.InvocationContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ульяна
 */
@WebServlet("/interExample")
public class InterceptorExample extends HttpServlet{
    
    @Inject
    LiveCycleBean liveCycleBean;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                liveCycleBean.doSurgery();
                liveCycleBean.doSurgery2();

    }
}
class MyInterceptor {
    @AroundConstruct
    private void aroundConstruct(InvocationContext invocationContext) throws Exception {
        System.out.println("before construct");
        invocationContext.proceed();
    }
    @PostConstruct
    private void postConstruct(InvocationContext invocationContext) throws Exception  {
        System.out.println("post construct");
        invocationContext.proceed();
    }
    @AroundInvoke
    private Object aroundMethods(InvocationContext context) throws Exception
    {
        System.out.println("before method");
        return context.proceed();
    }
    @PreDestroy
    private void preDestroy() {
        System.out.println("pre destroy");
    }
}
@RequestScoped
        @Interceptors(Interceptor.class)
    class LiveCycleBean {

        public LiveCycleBean() {
            System.out.println("construct");
        }
        @Interceptors(Interceptor.class)
        public void doSurgery() {
            System.out.println("do surgery");
        }
        @ExcludeClassInterceptors
        public void doSurgery2() {
            System.out.println("do surgery2");
    }
    }
